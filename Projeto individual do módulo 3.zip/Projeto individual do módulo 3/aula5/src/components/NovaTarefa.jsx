import React from 'react'

function NovaTarefa() {

    const [valorInput, setValorInput] = useState('');
  return (
    <div>
    </div>
  )
}

export default NovaTarefa