import React, { useState } from 'react';
import axios from 'axios';

function Tarefas() {

    const [tarefas, setTarefas] = useState([]);

    const requisitarFilmes = () => axios.get('http://localhost:3000/filmes')
      .then(function (response) {
        // handle success
        setTarefas(response.data);
        console.log(tarefas)
    })
      .catch(function (error) {
        // handle error
    
    })
      return (
        <div>
            {tarefas.map((e) => e.filme)} 
            <button onClick={requisitarFilmes}>Requisitar Filmes</button>
        </div>
      )
    }

export default Tarefas