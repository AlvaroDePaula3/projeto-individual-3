import './App.css'
import Tarefas from './components/mock/Tarefas'
function App() {

  return (
    <div className="App">
        <Tarefas/>
    </div>
  )
}

export default App
